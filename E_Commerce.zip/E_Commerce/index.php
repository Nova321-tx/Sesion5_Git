<?php
// index.php — página pública que muestra productos (no requiere sesión)
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Tienda - E-commerce</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#0b3954">
<style>
/* ==== ESTILOS PERSONALIZADOS PARA INDEX ==== */
body {
  font-family: "Segoe UI", sans-serif;
  background-color: #f4f6f8;
  color: #1a1a1a;
  margin: 0;
  padding: 0;
}

/* ENCABEZADO */
.header {
  background-color: #0b3954;
  color: white;
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 3px 8px rgba(0,0,0,0.2);
}

.header h1 {
  margin: 0;
  font-size: 1.6rem;
  letter-spacing: 0.5px;
}

#user-menu a, #user-menu button {
  color: white;
  text-decoration: none;
  font-weight: 600;
  background: none;
  border: none;
  margin-left: 12px;
  font-size: 0.95rem;
  cursor: pointer;
  transition: color 0.3s ease, background-color 0.3s ease;
}

#user-menu a:hover, #user-menu button:hover {
  color: #ffcc00;
}

/* CARRUSEL */
.carousel {
  width: 100%;
  height: 220px;
  overflow: hidden;
  position: relative;
  margin-bottom: 20px;
}

.carousel img {
  width: 100%;
  height: 220px;
  object-fit: cover;
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0;
  transition: opacity 0.8s ease-in-out;
}

.carousel img.active {
  opacity: 1;
}

/* BUSCADOR */
.search-bar {
  text-align: center;
  margin: 25px 0;
}

input#q {
  width: 45%;
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #ccc;
  transition: all 0.3s ease;
}

input#q:focus {
  outline: none;
  border-color: #0b3954;
  box-shadow: 0 0 5px rgba(11,57,84,0.4);
}

button {
  padding: 10px 16px;
  background-color: #0b3954;
  border: none;
  color: white;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  transition: background-color 0.3s ease, transform 0.2s;
}

button:hover {
  background-color: #107dac;
  transform: translateY(-2px);
}

/* PRODUCTOS */
#list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
  gap: 20px;
  width: 90%;
  margin: 0 auto 50px;
}

.product {
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  padding: 15px;
  text-align: center;
  transition: all 0.3s ease;
  cursor: pointer;
  overflow: hidden;
  display: flex;
  flex-direction: column; /* columna vertical */
}

.product:hover {
  transform: translateY(-6px) scale(1.03);
  box-shadow: 0 6px 18px rgba(0,0,0,0.2);
}

.product img {
  width: 100%;
  height: 180px;
  object-fit: cover;
  border-radius: 10px;
  transition: transform 0.4s ease;
}

.product:hover img {
  transform: scale(1.1);
}

.product h3 {
  margin: 12px 0 5px;
  color: #0b3954;
}

.product p {
  margin: 5px 0;
  font-size: 0.9rem;
  color: #444;
}

.product button {
  background-color: #0b3954;
  border: none;
  padding: 8px 14px;
  border-radius: 8px;
  color: white;
  font-weight: 600;
  transition: all 0.3s ease;
  margin-top: auto; /* empuja el botón hacia abajo */
}

.product button:hover {
  background-color: #107dac;
  transform: scale(1.05);
}

/* PIE DE PÁGINA */
footer {
  text-align: center;
  background-color: #0b3954;
  color: white;
  padding: 15px;
  font-size: 0.9rem;
  margin-top: 40px;
}
</style>
</head>
<body>

<div class="header">
  <h1>E-Commerce</h1>
  <div id="user-menu">
    <!-- se cargará dinámicamente -->
  </div>
</div>

<!-- Carrusel -->
<div class="carousel">
  <img src="assets/img/articulo1.jpg" class="active" alt="Promoción 1">
  <img src="assets/img/articulo2.jpg" alt="Promoción 2">
  <img src="assets/img/articulo3.jpg" alt="Promoción 3">
  <img src="assets/img/articulo4.jpg" alt="Promoción 4">
</div>

<!-- Buscador -->
<div class="search-bar">
  <input id="q" placeholder="Buscar productos...">
</div>

<!-- Lista de productos -->
<div id="list"></div>

<footer>
  © 2025 E-Commerce | Todos los derechos reservados
</footer>
<script>
const slides = document.querySelectorAll('.carousel img');
let currentSlide = 0;
const slideTime = 3000; // Duración por imagen (ms)

function showSlide(index){
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
  });
}

// Cambia la imagen cada `slideTime` ms
setInterval(() => {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}, slideTime);
/* ====== Manejo de usuario (login/logout) ====== */
function updateNav() {
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const menu = document.getElementById('user-menu');

  // 🔹 Muestra opciones según el estado de sesión
  if (user) {
    menu.innerHTML = `
      Hola, ${user.nombre} |
      <button onclick="logout()">Cerrar sesión</button> |
      <button onclick="goToCart()">Carrito 🛒</button>
    `;
  } else {
    menu.innerHTML = `
      <a href="login.php">Iniciar sesión</a> |
      <a href="registro.php">Registrarse</a> |
      <button onclick="goToCart()">Carrito 🛒</button>
    `;
  }
}

/* 🔸 Redirección segura al carrito */
function goToCart() {
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  if (!user || user.rol !== 'cliente') {
    alert("⚠️ Debes iniciar sesión como cliente para acceder al carrito");
    window.location.href = 'login.php';
  } else {
    window.location.href = 'carrito.php';
  }
}

/* 🔹 Cerrar sesión */
function logout() {
  localStorage.removeItem('user');
  updateNav();
}

updateNav();

/* ====== Productos y carrito ====== */
async function cargar() {
  const res = await fetch('api/productos.php');
  const data = await res.json();
  render(data);
}

// Búsqueda en tiempo real
const inputSearch = document.getElementById('q');
inputSearch.addEventListener('keyup', function() {
  const q = this.value.trim();
  if (!q) return cargar();
  buscar(q);
});

async function buscar(q) {
  const res = await fetch(`api/productos.php?q=${encodeURIComponent(q)}`);
  const data = await res.json();
  render(data);
}

// Render de productos
function render(items) {
  const cont = document.getElementById('list');
  cont.innerHTML = '';
  
  if (!items || !items.length) {
    cont.innerHTML = '<p style="text-align:center;color:#555;">No se encontraron productos.</p>';
    return;
  }

  items.forEach(p => {
    cont.innerHTML += `
    <div class="product">
      <img src="${p.imagen_url || 'assets/icons/icon-192.png'}" alt="">
      <h3>${p.nombre}</h3>
      <p>${p.descripcion || ''}</p>
      <p><b>$${p.precio}</b></p>
      <button onclick="addCart(${p.id})">Agregar</button>
    </div>`;
  });
}

function addCart(id) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const item = cart.find(x => x.id === id);
  if (item) {
    item.qty++;
  } else {
    cart.push({ id: id, qty: 1 });
  }
  localStorage.setItem('cart', JSON.stringify(cart));
  alert('✅ Producto añadido al carrito');
}

window.onload = cargar;
</script>
<script>
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then(() => console.log("✅ Service Worker registrado correctamente"))
    .catch(err => console.log("❌ Error al registrar Service Worker:", err));
}
</script>
</body>
</html>
