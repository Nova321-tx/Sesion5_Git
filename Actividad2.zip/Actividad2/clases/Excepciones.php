<?php
class LibroNoEncontradoException extends Exception {}
class DatosInvalidosException extends Exception {}
?>
