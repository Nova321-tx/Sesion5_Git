<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca POO</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>📚 Sistema de Gestión de Biblioteca</h1>
    <nav>
        <a href="index.php">Inicio</a> |
        <a href="index.php?accion=registrar">Registrar Libro</a>
    </nav>
</header>
<main>
