</main>
<footer>
    <p>© <?php echo date('Y'); ?> - Biblioteca PHP POO</p>
</footer>
</body>
</html>
