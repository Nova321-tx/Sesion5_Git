<h2>Registrar nuevo libro</h2>
<form method="post" action="index.php?accion=guardar">
    <h2>Registrar Nuevo Libro</h2>

    <label>Título:</label>
    <input type="text" name="titulo" required>

    <label>Autor:</label>
    <input type="text" name="autor" required>

    <label>Nacionalidad:</label>
    <input type="text" name="nacionalidad">

    <button type="submit">Guardar Libro</button>
</form>

